@extends('layouts.adminApp')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <section class="panel">
                <header class="panel-heading">
                    Common Adverse Events
                </header>
                <div class="panel-body">
                    <div class="abstract" id="abstract">
    
                              <div class="abstract-content selected" id="enc-abstract">
                              
                    
                      <p>
                        
                          <strong class="sub-title">
                            Aims:
                          </strong>
                        
                        To assess incidence, predictability, preventability and severity of adverse drug reactions (ADRs) in hospitalised oncology patients.
                      </p>
                    
                  
                  
                    
                      <p>
                        
                          <strong class="sub-title">
                            Patients and methods:
                          </strong>
                        
                        Patients hospitalised at Peter MacCallum Cancer Centre from 28 February to 2 June 2000 were selected for interviews about symptoms related to their drug therapy. Medical records were also reviewed. Causality, predictability, preventability and severity were assessed for each ADR.
                      </p>
                    
                  
                    
                      <p>
                        
                          <strong class="sub-title">
                            Results:
                          </strong>
                        
                        One hundred and sixty-seven patients associated with 171 admissions were interviewed. Four hundred and fifty-four ADRs were identified in 127 (74.3%) separate admissions (mean ADRs per admission 2.7; range 0-18). Eighty-eight percent of ADRs were predictable. Of these, 1.6% was classified as definitely preventable and 46.1% probably preventable. The ten most common ADRs were constipation, nausea +/- vomiting, fatigue, alopecia, drowsiness, myelosuppression, skin reactions, anorexia, mucositis and diarrhoea. These ADRs have high-documented incidence rates and were also the ten most predictable ADRs in this study. Common reasons for ADRs to be assessed as definitely or probably preventable were omission or inadequate/inappropriate use of preventative measures. The results also showed a discrepancy between clinical severity and patients' perception of the impact of ADRs on well being.
                      </p>
                    
                    
                      <p>
                        
                          <strong class="sub-title">
                            Conclusions:
                          </strong>
                        
                        ADRs are common in hospitalised oncology patients and are predictable and at least probably preventable in many instances. Improved use of preventative measures has the potential to contribute to reducing the incidence and severity of ADRs. Recognition and understanding of the discrepancy that exists between clinical severity and patient-perceived severity of ADRs will enable specific areas to be identified and targeted for vigourous intervention.
                      </p>
                              </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
@endsection